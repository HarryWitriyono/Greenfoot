import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Ulat here.
 * 
 * @author Harry 
 * @version (a version number or a date)
 */
public class Ulat extends Actor
{
    /**
     * Act - do whatever the Ulat wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        move(2);
        if (Greenfoot.getRandomNumber(100) <10)
           turn(Greenfoot.getRandomNumber(15)*30);
        ketemuKumbang();           
    }    
    public void ketemuKumbang() 
    {
        if (isTouching(kumbang.class))
        {
            removeTouching(kumbang.class);
            getWorld().showText("Kamu Kalah", 300, 300);
        }
    }
}
