import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        kumbang kumbang = new kumbang();
        addObject(kumbang,40,194);
        Cherry cherry = new Cherry();
        addObject(cherry,155,45);
        Cherry cherry2 = new Cherry();
        addObject(cherry2,281,101);
        Cherry cherry3 = new Cherry();
        addObject(cherry3,229,149);
        Cherry cherry4 = new Cherry();
        addObject(cherry4,470,183);
        Cherry cherry5 = new Cherry();
        addObject(cherry5,347,212);
        Cherry cherry6 = new Cherry();
        addObject(cherry6,465,73);
        Cherry cherry7 = new Cherry();
        addObject(cherry7,410,318);
        Cherry cherry8 = new Cherry();
        addObject(cherry8,192,319);
        Cherry cherry9 = new Cherry();
        addObject(cherry9,83,342);
        Cherry cherry10 = new Cherry();
        addObject(cherry10,302,366);
        Ulat ulat = new Ulat();
        addObject(ulat,302,37);
        Ulat ulat2 = new Ulat();
        addObject(ulat2,529,170);
        Ulat ulat3 = new Ulat();
        addObject(ulat3,302,283);
    }
}
