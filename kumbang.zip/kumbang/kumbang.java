import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class kumbang here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class kumbang extends Actor
{
    /**
     * Act - do whatever the kumbang wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    private int nilai=0;
    public void act() 
    {
        move(4);
        if (Greenfoot.isKeyDown("Down")) turn(4);
        if (Greenfoot.isKeyDown("Up")) turn(-4);
        ketemucherry();
    }    
    public void ketemucherry() {
        if (isTouching(Cherry.class)) 
           {
               removeTouching(Cherry.class);
               nilai=nilai+1;
               getWorld().showText("Nilai: "+nilai, 50, 50);
               if (nilai==10) {
                   getWorld().showText("Selamat kamu menang !",250,250);
                   Greenfoot.stop();
                }
            }
    }
}
