import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Shot Giant Frog (Tembak Kodok Raksasa)
 * Dibuat oleh : Harry Witriyono, M.Kom
 * Untuk mahasiswa kelas mata kuliah Permodelan Berorientasi Obyek
 * @version 1 (C)2019
 */
public class Kid extends Actor
{
    /**
     * Act - do whatever the Kid wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    public void act() 
    {
        // Add your action code here.
        
        if (Greenfoot.isKeyDown("Right")) jalanmaju();
        if (Greenfoot.isKeyDown("Left")) jalanmundur();
        if (Greenfoot.isKeyDown("Up")) keatas();
        if (Greenfoot.isKeyDown("Down")) kebawah();
        if (Greenfoot.isKeyDown("Space")) menembak();
        if (isTouching(Kodok.class))
        {
           MyWorld.kurangiumur(1); //panggil metode kurangiumur di MyWorld
           if (MyWorld.umur<1)
           { 
               Greenfoot.stop();
            }
        }
    }   
    public void jalanmaju()
    {
        move(5);
    }
    public void jalanmundur()
    {
        move(-5);
    }
    public void keatas()
    {
        setLocation(getX(),getY()-5);
    }
    public void kebawah()
    {
        setLocation(getX(),getY()+5);
    }
    public void menembak()
    {
       Batu batu = new Batu();
       getWorld().addObject(batu,getX()+15,getY());
    }
}
