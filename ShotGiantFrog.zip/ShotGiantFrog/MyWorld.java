import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public static int umur=10;
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Kid kid = new Kid();
        addObject(kid,17,189);
       /* Kodok kodok = new Kodok();
        addObject(kodok,571,61);
        Kodok kodok2 = new Kodok();
        addObject(kodok2,520,190);
        Kodok kodok3 = new Kodok();
        addObject(kodok3,583,310);
        Kodok kodok4 = new Kodok();
        addObject(kodok4,356,325);
        Kodok kodok5 = new Kodok();
        addObject(kodok5,309,149);
        Kodok kodok6 = new Kodok();
        addObject(kodok6,445,97); */
        for(int i=0;i<5;i++) //untuk kodok 1 s/d 5
        {
            Kodok kodok = new Kodok(); //buat obyek
            addObject(kodok,
                580,
                Greenfoot.getRandomNumber(400));    // meletakkan obyek
        };
        showText("Shoot The Frog", 300, 50);
        showText("Nilai : ", 50, 50);
        umur=100;
        showText("Umur:"+umur, 550,50);
    }
    public void act()
    {
        showText("Umur:"+umur, 550,50);
        if (umur<0) 
        {
            showText("Kamu Kalah !", 250, 250);
          //  Greenfoot.stop();
        }
    }
    public static void kurangiumur(int x)
    {
       umur=umur-x;     
    }
}
