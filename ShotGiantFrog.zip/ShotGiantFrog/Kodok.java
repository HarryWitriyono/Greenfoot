import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Shot Giant Frog (Tembak Kodok Raksasa)
 * Dibuat oleh : Harry Witriyono, M.Kom
 * Untuk mahasiswa kelas mata kuliah Permodelan Berorientasi Obyek
 * @version 1 (C)2019
 */
public class Kodok extends Actor
{
    /**
     * Act - do whatever the Kodok wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public static int nilai;
    public void act() 
    {
        // Add your action code here.
        move(-3);
        if (isTouching(Batu.class))
        {
            nilai=nilai+10;
            getWorld().showText("Nilai : "+ nilai, 50, 50);
            Kodok katak = new Kodok();
            getWorld().addObject(katak, 
            600, Greenfoot.getRandomNumber(400));
            removeTouching(Batu.class);
            getWorld().removeObject(this);
        } else if (isAtEdge())
        {
            Kodok katak = new Kodok();
            getWorld().addObject(katak, 600, Greenfoot.getRandomNumber(400));
            getWorld().removeObject(this);
        }
        
    }    
}
