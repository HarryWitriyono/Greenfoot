import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Blast here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

public class Blast extends Actor
{
    int counter=0;
    public Blast()
    {
        setImage("blast.png");
    }

    public void act() 
    {
        counter++; //counter = counter + 1 ;
        if (counter==5) 
        {
            Greenfoot.playSound("blast.wav");
            getWorld().removeObject(this);
        }
    }    
}
