import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Hero here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Hero extends Actor
{
    /**
     * Act - do whatever the Hero wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    int counter=0;
    {
        setImage("rocket.png");
    }
    public void shoot()
    {
        Ammo ammo = new Ammo(); 
        getWorld().addObject(ammo, getX(), getY()); //ambil dari world untuk obyek ammo
    }

    public void act() 
    {
        counter++; //counter = counter + 1 ;
        if (counter==60) 
        {
            counter=0;
            Greenfoot.playSound("ammo.wav");
            shoot();
        }
        //jika mouse bergerak
        /*  if (Greenfoot.mouseDragged(this)) //jika mouse di dragged maka 
        { //lokasi hero menjadi lokasi x dan y dari mouse
        setLocation(Greenfoot.getMouseInfo().getX(),Greenfoot.getMouseInfo().getY());
        }

         */   
        // diganti agar bisa dikonvesi ke Android yang tidak ada keyboard
        // jika pencet atas maka naik
        if (Greenfoot.isKeyDown("up"))
        {
        setLocation(getX(), getY()-3);

        } 
        else if (Greenfoot.isKeyDown("down")) {
        setLocation(getX(), getY()+3);

        } 
        if (Greenfoot.isKeyDown("left")) {
        setLocation(getX()-3, getY());
        } 
        else if (Greenfoot.isKeyDown("right")) {
        setLocation(getX()+3, getY());
        } 

        // */       
        if (isTouching(Enemy.class) )
        {
            MyWorld.hp.add(-1);
            if (MyWorld.hp.getValue()<=0) //jika HP = 0 maka game over
            {
                Label go = new Label("Game over",50);
                getWorld().addObject(go, 150, 250);
                Greenfoot.playSound("blast.wav");
                MyWorld.bg.stop();
                MyWorld.bg = new GreenfootSound("bg4.wav");
                MyWorld.bg.playLoop();
                Greenfoot.stop();

            }
            removeTouching(Enemy.class);
            Enemy enemy = new Enemy(Greenfoot.getRandomNumber(5)); //buat obyek enemy baru
            //tambahkan obyeknya dengan posisi X acak
            getWorld().addObject(enemy,Greenfoot.getRandomNumber(291)+5, 0);
            getWorld().addObject(new Blast(),getX(), getY());
            Greenfoot.playSound("hit.wav");

        }
    }    
}
