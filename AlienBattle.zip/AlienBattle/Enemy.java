import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Enemy here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

public class Enemy extends Actor // class Enemy anaknya Actor
{
    int speed = 3; //menambah property speed pada kelas enemy dengan nilai default=3
    public Enemy()
    {
        this.speed=2; //boleh diganti speed =2;
        this.setImage("Alien1.png"); // boleh diganti setImage("Alien1.png");
    }
    public Enemy(int type)
    {
        this.speed=type/2+1; //boleh diganti speed =2;
        this.setImage("Alien"+type+".png"); // boleh diganti setImage("Alien1.png");
    }
    public void act() //awal methode act cirinya ada () 
    {
        setLocation(getX(),  getY()+speed); //angka 1 diganti speed
        // jika mentok sampai bawah maka kembali ke atas :
        if (getY()>=495)  // 
        {
            setLocation(Greenfoot.getRandomNumber(300),0);  
        }
        
    }    
}
