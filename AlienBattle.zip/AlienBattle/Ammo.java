import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Ammo here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Ammo extends Actor
{
    /**
     * Act - do whatever the Ammo wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Ammo()
    {
        setImage("bullet.png");
    }
    public void act() 
    {
        // Add your action code here.
       setLocation(getX(),getY()-10); //gerak peluru
       if (getY()<=5)  // kalau sampai pinggi layar maka pelurunya digeser
       {
         getWorld().removeObject(this);//buang object ini ya    
        } 
       else if (isTouching(Enemy.class))
       {
           removeTouching(Enemy.class); //buang object yang tersentuh
           Greenfoot.playSound("blast.wav");
           Enemy enemy = new Enemy(Greenfoot.getRandomNumber(5)); //buat obyek enemy baru
           //tambahkan obyeknya dengan posisi X acak
           getWorld().addObject(enemy,Greenfoot.getRandomNumber(291)+5, 0);
           //getRandomNumber(301) artinya ambil 300 angkat mulai dari 0
           /*getRandomNumber(291)+5 artinya ambil 291 angkat + 5 jadi mulai
            * dari angkar 5
           */
           getWorld().addObject(new Blast(),getX(), getY());
           /*ini sama dengan :
              Blast blast = new Blast();
              getWorld().addObject(blast,getX(), getY());
           */
           /* Untuk menambah skor skor.add(10)
            */
           MyWorld.skor.add(10);
           getWorld().removeObject(this);//buang object ini ya 
           
        }
    }    
}
