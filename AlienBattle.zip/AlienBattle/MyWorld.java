import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{

    public static Counter skor = new Counter("Score : "); 
    /** menjadikan skor variabel global 
     *  penggunaan public dan static untuk bisa dibaca di manapun.
     *  static dibuat karena akan diakses class lain 
     *  public supaya lebih jelas digunakan dimanapun.
     */
    public static Counter hp = new Counter("HP: "); 
    public static GreenfootSound bg = new GreenfootSound("bg1.wav");
    Hero hero = new Hero();
    int xhero,yhero;
    int xmouse,ymouse;
    public MyWorld() // <= Constructor MyWorld
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(300, 500, 1); 
        prepare();
        setBackground("bg-hitam.png");

    }

    public void started()
    {
        bg.playLoop();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        for(int i=0;i<5;i++)
        {
            Enemy enemy = new Enemy(Greenfoot.getRandomNumber(4)); //buat obyek
            addObject(enemy,
                Greenfoot.getRandomNumber(300),
                Greenfoot.getRandomNumber(200));    // meletakkan obyek
        };

        //enemy.speed=1; //dimatikan karena sudah ada konstruk di class enemy
        //enemy.setImage("Alien0.png");
        //enemy2.speed=2;
        //enemy2.setImage("Alien1.png");
        //enemy3.speed=3;
        //enemy3.setImage("Alien2.png");

        
        addObject(hero,141,459);

        addObject(skor,45,23);
        skor.setValue(0); //mengeset nilainya menjadi 0;
        addObject(hp,260,23);
        hp.setValue(5);
    }

    public void act(){

        if(Greenfoot.mousePressed(this))
        {
            MouseInfo mouse=Greenfoot.getMouseInfo();
            xmouse = mouse.getX();
            ymouse = mouse.getY();

        }
        if(Greenfoot.mouseDragged(this))
        {
            MouseInfo mouse=Greenfoot.getMouseInfo();
            xhero=hero.getX();
            yhero=hero.getY();
            hero.setLocation(xhero+(mouse.getX()-xmouse), yhero+(mouse.getY()-ymouse));
            xmouse = mouse.getX();
            ymouse = mouse.getY();

        }
    }

}
